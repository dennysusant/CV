from flask import Flask, abort, jsonify, render_template,url_for, request,send_from_directory,redirect
import os
from werkzeug.utils import secure_filename
app=Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')
@app.route('/kedua')
def kedua():
    return render_template('index.html')

if __name__=='__main__':
    app.run(
    debug= True,
    host = '0.0.0.0',
    port = 99999
    )




